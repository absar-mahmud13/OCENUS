// script.js

document.getElementById('region').addEventListener('change', function () {
    const region = this.value;
    alert("Real-time data for " + region + " will be available soon.");
});
